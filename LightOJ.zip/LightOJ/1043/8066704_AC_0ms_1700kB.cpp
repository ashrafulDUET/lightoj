    #include<bits/stdc++.h>
    using namespace std;
    int main()
    {
        //freopen("in.txt","r",stdin);
        double ab,bc,ac,ration;
        int tc;
        scanf("%d",&tc);
        for(int i=1;i<=tc;i++)
        {
            scanf("%lf%lf%lf%lf",&ab,&ac,&bc,&ration);
            printf("Case %d: %.10lf\n",i,(sqrt(ration)/sqrt(ration+1)*ab));
        }


        return 0;

    }
