
    #include<bits/stdc++.h>
    using namespace std;
    struct edge{
        int u,v,w;
        bool operator <(const edge &p)const{
            return (w<p.w);
        }
    };

    vector<edge>e;
    int p[100005];
    map<string,int>mp;
    int findp(int x){
        if(p[x] == x) return x;
        return p[x] = findp(p[x]);
    }
    int MST(int n){  //start Minimum spanning tree
        sort(e.begin(),e.end());
        for(int i=1;i<=n;i++){ //make itself parents
                p[i] = i;
            }
        int cost =0, num =0,u,v;
        for(int j=1,i =0 ;i<e.size(); i++){
            u = e[i].u;
            v = e[i].v;
            if(findp(u) != findp(v)){
                 p[p[u]] = p[v];//Same as : p[findp(u)] = p[v];
                cost += e[i].w;
                num++;
            }
            if(num == n) break;
        }
        return cost;
    }   //End MST
    //--->>>>>>>>----------->>START BFS<<-----------<<<<<<<<<<<<<<---
    bool vis[1000];
    queue<int> qb;
    vector<int>vec[1000];
    void bfs(int src)
        {

            qb.push(src);
            vis[src]=1;
            while(!qb.empty())
            {
                int u = qb.front();
                qb.pop();
                //cout<<u<<" ";
                for(int i=0,len = vec[u].size();i<len;i++)
                {
                    if(vis[vec[u][i]]==0)
                    {
                        qb.push(vec[u][i]);
                        vis[vec[u][i]] = 1;

                    }
                }
            }

        }
    //------
    int main(){
        //freopen("in.txt","r",stdin);
        int tc,nE,nN,w,m,re,cnt; edge ed; string u,v;
        cin>>tc;
        for(int t=1;t<=tc;t++){
            nN=cnt=0;m=1;e.clear();mp.clear();
            cin>>nE;
            for(int i =0;i<nE; i++){
                cin>>u>>v>>w;
                if(mp.find(u)==mp.end()){
                        mp[u] =m++;
                        nN++;
                }
                if(mp.find(v)==mp.end()){
                    mp[v] =m++;
                    nN++;
                }
                ed.u = mp[u];
                ed.v = mp[v];
                ed.w = w;
                e.push_back(ed);
                vec[mp[v]].push_back(mp[u]);
                vec[mp[u]].push_back(mp[v]);
            }
            for(int i =1;i<=nN;i++)
            {
                if(vis[i]==0)
                {
                    bfs(i);
                    cnt++;
                }
            }
            if(cnt==1){
                re = MST(nN);
                cout<<"Case "<<t<<": "<<re<<endl;
            }
            else{
                cout<<"Case "<<t<<": Impossible"<<endl;
            }
            for(int i=1;i<=nN;i++){
                vec[i].clear();
                vis[i]=0;
            }

        }
        return 0;
    }
