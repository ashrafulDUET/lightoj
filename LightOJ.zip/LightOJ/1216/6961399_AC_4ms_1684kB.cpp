#include<iostream>
#include<stdio.h>
#include<cmath>
#include<iomanip>
using namespace std;

int main()
{
    const double PI=acos(-1);
    double r1,r2,h,p,k,r;
    int Case;
    cin>>Case;
    for(int i=1;i<=Case; i++){
        cin>>r1>>r2>>h>>p;
        k = (h*r2)/(r1-r2);
        r = (r2*(k+p))/k;
        cout<<fixed<<setprecision(9);
        cout<<"Case "<<i<<": "<<((PI*r*r*(p+k)) - (PI*r2*r2*k))/3<<endl;
    }
    return 0;
}
