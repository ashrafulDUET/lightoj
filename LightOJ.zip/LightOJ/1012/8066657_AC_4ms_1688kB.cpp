#include<bits/stdc++.h>
using namespace std;
int co=1;
char arr[22][22];
void cou(int i,int j)
{

    if(arr[i][j-1]=='.')
    {
        arr[i][j-1]='o';
        co++;
        cou(i,j-1);
    }
    if(arr[i][j+1]=='.')
    {
        arr[i][j+1]='o';
        co++;
        cou(i,j+1);
    }
    if(arr[i-1][j]=='.')
    {
        arr[i-1][j]='o';
        co++;
        cou(i-1,j);
    }
    if(arr[i+1][j]=='.')
    {
        arr[i+1][j]='o';
        co++;
        cou(i+1,j);
    }
}
int main()
{
    //freopen("in.txt","r",stdin);
    int w,h,t,pi,pj;
    char ch;
    scanf("%d",&t);
    for(int i =1;i<=t;i++)
    {
        memset(arr,0,sizeof(arr));
        co =1;
        scanf("%d%d%*d",&w,&h);
        for(int j =0;j<h;j++)
        {
            for(int k=0;k<w;k++)
            {
                scanf("%c",&arr[j][k]);
                if(arr[j][k]=='@')
                {
                    pi =j;
                    pj = k;
                }
            }
            scanf("%c",&ch);
        }
        arr[pi][pj]='%';
        cou(pi,pj);

        printf("Case %d: %d\n",i,co);
    }


    return 0;
}
