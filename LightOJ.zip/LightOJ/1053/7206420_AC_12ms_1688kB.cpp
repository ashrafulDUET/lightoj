#include<iostream>
#include<cmath>
#include<vector>
#include<algorithm>
using namespace std;
int a[3];
int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t; i++)
    {
        cin>>a[0]>>a[1]>>a[2];
        sort(a,a+3);
        if(a[0]*a[0]+a[1]*a[1]==a[2]*a[2])
            cout<<"Case "<<i<<": "<<"yes"<<endl;
        else
            cout<<"Case "<<i<<": "<<"no"<<endl;
    }
    return 0;
}
