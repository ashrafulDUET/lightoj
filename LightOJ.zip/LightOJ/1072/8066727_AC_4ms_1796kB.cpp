#include<iostream>
#include<stdio.h>
#include<cmath>
using namespace std;
const double pi=acos(-1);

int main(){
	int numcas;cin>>numcas;
	int cid=0;
	cout<< fixed;cout.precision(10);
	while(numcas--){
		double R,n;cin>>R>>n;
		cout<<"Case "<<++cid<<": "<<sin(pi/n)*R/(sin(pi/n) + 1)<<endl;
	}
	return 0;
}
